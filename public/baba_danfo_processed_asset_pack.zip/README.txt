BABA DANFO - PROCESSED ART DROP

Contains the original atlas, transparent action sheets cropped to animation families, and automatically extracted visible pose/effect components.

Folders:
- master_atlas.png: full generated atlas (1536x1024)
- *_sheet.png: transparent cropped sequence sheets, with headings removed
- frames/<animation>/*.png: alpha-isolated connected-component crops, useful as pose samples
- animation_manifest.json: crop bounds, detected frame counts and dimensions

IMPORTANT: these are crops from a generated atlas, NOT hand-authored consistent frame grids. Some action frames can be combined with glow/shadow or be split into multiple components. Inspect and sequence them before treating them as animation-ready. Frame rate and animation mapping are not defined.

Baba identity: dark-skinned muscular Lagos street fighter; yellow Danfo cap, yellow/black conductor jacket, black shirt and trousers, gold chain, yellow accents and boots.

UNIFORM FRAMES (experimental automated slicing):
- uniform_frames/<animation>/: fixed 128x160 transparent PNGs, numbered in sequence
- <animation>_frames_128x160.png: horizontal strip of those fixed frames
- Animation frame counts are approximate guesses from the atlas; inspect each strip before wiring into the game. Automated equal-width slicing may split or merge some generated poses imperfectly.
